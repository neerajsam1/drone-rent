from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import crud
from .database import Base, engine, get_db
from .models import Drone, DroneStatus
from .schemas import (
    DashboardStats,
    DroneCreate,
    DroneResponse,
    DroneUpdate,
    RentalRequest,
    RentalResponse,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Drone Rental Management API",
    version="1.0.0",
    description="Inventory and rental management for a drone fleet.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "drone-rent"}


@app.get("/api/drones", response_model=list[DroneResponse])
def list_drones(
    search: str | None = Query(default=None),
    status: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    return crud.get_drones(db, search=search, status=status)


@app.get("/api/drones/{drone_db_id}", response_model=DroneResponse)
def get_drone(drone_db_id: int, db: Session = Depends(get_db)):
    drone = crud.get_drone(db, drone_db_id)
    if not drone:
        raise HTTPException(status_code=404, detail="Drone not found")
    return drone


@app.post("/api/drones", response_model=DroneResponse, status_code=201)
def create_drone(drone: DroneCreate, db: Session = Depends(get_db)):
    try:
        return crud.create_drone(db, drone)
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="Drone ID or serial number already exists",
        )


@app.put("/api/drones/{drone_db_id}", response_model=DroneResponse)
def update_drone(
    drone_db_id: int,
    changes: DroneUpdate,
    db: Session = Depends(get_db),
):
    drone = crud.get_drone(db, drone_db_id)
    if not drone:
        raise HTTPException(status_code=404, detail="Drone not found")

    try:
        return crud.update_drone(db, drone, changes)
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="Drone ID or serial number already exists",
        )


@app.delete("/api/drones/{drone_db_id}", status_code=204)
def delete_drone(drone_db_id: int, db: Session = Depends(get_db)):
    drone = crud.get_drone(db, drone_db_id)
    if not drone:
        raise HTTPException(status_code=404, detail="Drone not found")
    crud.delete_drone(db, drone)


@app.post(
    "/api/drones/{drone_db_id}/rent",
    response_model=RentalResponse,
)
def rent_drone(
    drone_db_id: int,
    rental: RentalRequest,
    db: Session = Depends(get_db),
):
    drone = crud.get_drone(db, drone_db_id)

    if not drone:
        raise HTTPException(status_code=404, detail="Drone not found")

    if drone.status != DroneStatus.AVAILABLE.value:
        raise HTTPException(
            status_code=409,
            detail=f"Drone is not available. Current status: {drone.status}",
        )

    total = round(drone.daily_rental_price * rental.days, 2)
    drone.status = DroneStatus.RENTED.value
    db.commit()

    return RentalResponse(
        drone_id=drone.drone_id,
        customer_name=rental.customer_name,
        days=rental.days,
        daily_rate=drone.daily_rental_price,
        total_price=total,
        status=drone.status,
    )


@app.post("/api/drones/{drone_db_id}/return", response_model=DroneResponse)
def return_drone(drone_db_id: int, db: Session = Depends(get_db)):
    drone = crud.get_drone(db, drone_db_id)

    if not drone:
        raise HTTPException(status_code=404, detail="Drone not found")

    if drone.status != DroneStatus.RENTED.value:
        raise HTTPException(
            status_code=409,
            detail="Only a rented drone can be returned",
        )

    drone.status = DroneStatus.AVAILABLE.value
    db.commit()
    db.refresh(drone)
    return drone


@app.get("/api/stats", response_model=DashboardStats)
def stats(db: Session = Depends(get_db)):
    all_drones = list(db.scalars(select(Drone)).all())

    counts = {
        status: sum(1 for d in all_drones if d.status == status.value)
        for status in DroneStatus
    }

    return DashboardStats(
        total=len(all_drones),
        available=counts[DroneStatus.AVAILABLE],
        reserved=counts[DroneStatus.RESERVED],
        rented=counts[DroneStatus.RENTED],
        maintenance=counts[DroneStatus.MAINTENANCE],
        retired=counts[DroneStatus.RETIRED],
    )
