from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from .models import Drone, DroneStatus
from .schemas import DroneCreate, DroneUpdate


def get_drone(db: Session, drone_db_id: int):
    return db.get(Drone, drone_db_id)


def get_drones(
    db: Session,
    search: str | None = None,
    status: str | None = None,
):
    stmt = select(Drone).order_by(Drone.id.desc())

    if search:
        pattern = f"%{search}%"
        stmt = stmt.where(
            or_(
                Drone.drone_id.ilike(pattern),
                Drone.name.ilike(pattern),
                Drone.model.ilike(pattern),
                Drone.serial_number.ilike(pattern),
                Drone.category.ilike(pattern),
            )
        )

    if status:
        stmt = stmt.where(Drone.status == status)

    return list(db.scalars(stmt).all())


def create_drone(db: Session, drone: DroneCreate):
    obj = Drone(**drone.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


def update_drone(db: Session, obj: Drone, changes: DroneUpdate):
    for field, value in changes.model_dump(exclude_unset=True).items():
        setattr(obj, field, value)
    db.commit()
    db.refresh(obj)
    return obj


def delete_drone(db: Session, obj: Drone):
    db.delete(obj)
    db.commit()


def count_status(db: Session, status: str):
    stmt = select(Drone).where(Drone.status == status)
    return len(list(db.scalars(stmt).all()))
