from datetime import date

from .database import Base, SessionLocal, engine
from .models import Drone, DroneStatus

Base.metadata.create_all(bind=engine)

demo_drones = [
    {
        "drone_id": "DR-001",
        "name": "DJI Agras T50",
        "category": "Agriculture",
        "manufacturer": "DJI",
        "model": "Agras T50",
        "serial_number": "DEMO-T50-001",
        "purchase_date": date(2026, 1, 15),
        "purchase_cost": 12000,
        "daily_rental_price": 500,
        "status": DroneStatus.AVAILABLE.value,
        "location": "Glasgow",
        "battery_count": 4,
        "flight_hours": 25,
        "last_maintenance": date(2026, 8, 1),
        "next_maintenance": date(2026, 11, 1),
        "notes": "Agricultural spraying drone.",
    },
    {
        "drone_id": "DR-002",
        "name": "DJI Matrice 350",
        "category": "Events",
        "manufacturer": "DJI",
        "model": "Matrice 350 RTK",
        "serial_number": "DEMO-M350-001",
        "purchase_date": date(2026, 2, 10),
        "purchase_cost": 8500,
        "daily_rental_price": 350,
        "status": DroneStatus.AVAILABLE.value,
        "location": "Edinburgh",
        "battery_count": 6,
        "flight_hours": 40,
        "last_maintenance": date(2026, 8, 15),
        "next_maintenance": date(2026, 12, 15),
        "notes": "Suitable for commercial photography and inspection.",
    },
    {
        "drone_id": "DR-003",
        "name": "Event Camera Drone",
        "category": "Events",
        "manufacturer": "DJI",
        "model": "Mavic 3 Pro",
        "serial_number": "DEMO-M3P-001",
        "purchase_date": date(2026, 3, 5),
        "purchase_cost": 2200,
        "daily_rental_price": 150,
        "status": DroneStatus.MAINTENANCE.value,
        "location": "Glasgow",
        "battery_count": 3,
        "flight_hours": 70,
        "last_maintenance": date(2026, 9, 1),
        "next_maintenance": date(2026, 9, 30),
        "notes": "Due for inspection before next rental.",
    },
]


def seed():
    db = SessionLocal()
    try:
        existing = {d.drone_id for d in db.query(Drone).all()}
        for data in demo_drones:
            if data["drone_id"] not in existing:
                db.add(Drone(**data))
        db.commit()
        print("Demo drones added.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
