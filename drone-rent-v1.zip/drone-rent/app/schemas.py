from datetime import date, datetime
from pydantic import BaseModel, ConfigDict, Field

from .models import DroneStatus


class DroneBase(BaseModel):
    drone_id: str = Field(min_length=1, max_length=50)
    name: str = Field(min_length=1, max_length=150)
    category: str = Field(min_length=1, max_length=50)
    manufacturer: str = Field(min_length=1, max_length=100)
    model: str = Field(min_length=1, max_length=100)
    serial_number: str = Field(min_length=1, max_length=100)
    purchase_date: date | None = None
    purchase_cost: float = Field(default=0, ge=0)
    daily_rental_price: float = Field(default=0, ge=0)
    status: DroneStatus = DroneStatus.AVAILABLE
    location: str = ""
    battery_count: int = Field(default=0, ge=0)
    flight_hours: float = Field(default=0, ge=0)
    last_maintenance: date | None = None
    next_maintenance: date | None = None
    notes: str = ""


class DroneCreate(DroneBase):
    pass


class DroneUpdate(BaseModel):
    drone_id: str | None = Field(default=None, min_length=1, max_length=50)
    name: str | None = Field(default=None, min_length=1, max_length=150)
    category: str | None = Field(default=None, min_length=1, max_length=50)
    manufacturer: str | None = Field(default=None, min_length=1, max_length=100)
    model: str | None = Field(default=None, min_length=1, max_length=100)
    serial_number: str | None = Field(default=None, min_length=1, max_length=100)
    purchase_date: date | None = None
    purchase_cost: float | None = Field(default=None, ge=0)
    daily_rental_price: float | None = Field(default=None, ge=0)
    status: DroneStatus | None = None
    location: str | None = None
    battery_count: int | None = Field(default=None, ge=0)
    flight_hours: float | None = Field(default=None, ge=0)
    last_maintenance: date | None = None
    next_maintenance: date | None = None
    notes: str | None = None


class DroneResponse(DroneBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
    updated_at: datetime


class RentalRequest(BaseModel):
    customer_name: str = Field(min_length=1, max_length=150)
    days: int = Field(gt=0, le=365)


class RentalResponse(BaseModel):
    drone_id: str
    customer_name: str
    days: int
    daily_rate: float
    total_price: float
    status: str


class DashboardStats(BaseModel):
    total: int
    available: int
    reserved: int
    rented: int
    maintenance: int
    retired: int
