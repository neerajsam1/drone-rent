let drones = [];

async function api(url, options = {}) {
    const response = await fetch(url, {
        headers: {"Content-Type": "application/json"},
        ...options
    });

    if (!response.ok) {
        let message = "Request failed";
        try {
            const data = await response.json();
            message = data.detail || message;
        } catch {}
        throw new Error(message);
    }

    if (response.status === 204) return null;
    return response.json();
}

async function loadStats() {
    const data = await api("/api/stats");
    document.getElementById("total").textContent = data.total;
    document.getElementById("available").textContent = data.available;
    document.getElementById("rented").textContent = data.rented;
    document.getElementById("maintenance").textContent = data.maintenance;
}

async function loadDrones() {
    try {
        const search = document.getElementById("search").value;
        const status = document.getElementById("statusFilter").value;

        const params = new URLSearchParams();
        if (search) params.set("search", search);
        if (status) params.set("status", status);

        drones = await api("/api/drones?" + params.toString());
        renderDrones();
        loadStats();
    } catch (error) {
        alert(error.message);
    }
}

function renderDrones() {
    const tbody = document.getElementById("droneTable");

    if (!drones.length) {
        tbody.innerHTML = `<tr><td colspan="8">No drones found.</td></tr>`;
        return;
    }

    tbody.innerHTML = drones.map(d => `
        <tr>
            <td><strong>${escapeHtml(d.drone_id)}</strong></td>
            <td>${escapeHtml(d.name)}<br><small>${escapeHtml(d.model)}</small></td>
            <td>${escapeHtml(d.category)}</td>
            <td>${escapeHtml(d.location || "-")}</td>
            <td>£${Number(d.daily_rental_price).toFixed(2)}</td>
            <td>${Number(d.flight_hours).toFixed(1)}</td>
            <td><span class="badge ${d.status.toLowerCase()}">${d.status}</span></td>
            <td>
                <div class="actions">
                    <button onclick="editDrone(${d.id})">Edit</button>
                    ${d.status === "AVAILABLE"
                        ? `<button onclick="openRental(${d.id})">Rent</button>`
                        : ""}
                    ${d.status === "RENTED"
                        ? `<button onclick="returnDrone(${d.id})">Return</button>`
                        : ""}
                    <button onclick="deleteDrone(${d.id})">Delete</button>
                </div>
            </td>
        </tr>
    `).join("");
}

function openDroneForm(drone = null) {
    document.getElementById("modal").classList.remove("hidden");
    document.getElementById("modalTitle").textContent = drone ? "Edit Drone" : "Add Drone";
    document.getElementById("droneForm").reset();
    document.getElementById("editId").value = drone ? drone.id : "";

    if (!drone) {
        document.getElementById("manufacturer").value = "DJI";
        document.getElementById("status").value = "AVAILABLE";
        return;
    }

    for (const key of [
        "drone_id", "name", "category", "manufacturer", "model",
        "serial_number", "purchase_date", "purchase_cost",
        "daily_rental_price", "status", "location", "battery_count",
        "flight_hours", "last_maintenance", "next_maintenance", "notes"
    ]) {
        const el = document.getElementById(key);
        if (el) el.value = drone[key] ?? "";
    }
}

function closeModal() {
    document.getElementById("modal").classList.add("hidden");
}

async function editDrone(id) {
    try {
        const drone = await api(`/api/drones/${id}`);
        openDroneForm(drone);
    } catch (error) {
        alert(error.message);
    }
}

document.getElementById("droneForm").addEventListener("submit", async event => {
    event.preventDefault();

    const fields = [
        "drone_id", "name", "category", "manufacturer", "model",
        "serial_number", "purchase_date", "purchase_cost",
        "daily_rental_price", "status", "location", "battery_count",
        "flight_hours", "last_maintenance", "next_maintenance", "notes"
    ];

    const payload = {};
    for (const field of fields) {
        const value = document.getElementById(field).value;
        payload[field] = value === "" ? null : value;
    }

    ["purchase_cost", "daily_rental_price", "battery_count", "flight_hours"].forEach(k => {
        if (payload[k] !== null) payload[k] = Number(payload[k]);
    });

    const editId = document.getElementById("editId").value;

    try {
        await api(editId ? `/api/drones/${editId}` : "/api/drones", {
            method: editId ? "PUT" : "POST",
            body: JSON.stringify(payload)
        });

        closeModal();
        await loadDrones();
    } catch (error) {
        alert(error.message);
    }
});

async function deleteDrone(id) {
    if (!confirm("Delete this drone from the inventory?")) return;

    try {
        await api(`/api/drones/${id}`, {method: "DELETE"});
        await loadDrones();
    } catch (error) {
        alert(error.message);
    }
}

function openRental(id) {
    document.getElementById("rentalId").value = id;
    document.getElementById("rentalForm").reset();
    document.getElementById("rentalDays").value = 1;
    document.getElementById("rentalModal").classList.remove("hidden");
}

function closeRental() {
    document.getElementById("rentalModal").classList.add("hidden");
}

document.getElementById("rentalForm").addEventListener("submit", async event => {
    event.preventDefault();

    const id = document.getElementById("rentalId").value;
    const customer_name = document.getElementById("customerName").value;
    const days = Number(document.getElementById("rentalDays").value);

    try {
        const result = await api(`/api/drones/${id}/rent`, {
            method: "POST",
            body: JSON.stringify({customer_name, days})
        });

        closeRental();

        alert(
            `Rental confirmed!\n\n` +
            `Customer: ${result.customer_name}\n` +
            `Drone: ${result.drone_id}\n` +
            `Days: ${result.days}\n` +
            `Daily rate: £${result.daily_rate.toFixed(2)}\n` +
            `Total: £${result.total_price.toFixed(2)}`
        );

        await loadDrones();
    } catch (error) {
        alert(error.message);
    }
});

async function returnDrone(id) {
    if (!confirm("Mark this drone as returned and available?")) return;

    try {
        await api(`/api/drones/${id}/return`, {method: "POST"});
        await loadDrones();
    } catch (error) {
        alert(error.message);
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

loadDrones();
