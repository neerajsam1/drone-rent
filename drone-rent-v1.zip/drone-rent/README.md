# Drone Rental Management System

A simple first version of a drone fleet inventory and rental management system.

## Features

- Add, view, edit and delete drones
- Search drones by name, model, serial number or category
- Filter by availability/status
- Track:
  - purchase cost
  - rental price
  - location
  - battery count
  - flight hours
  - maintenance dates
  - notes
- Record a rental
- Return a rented drone
- Calculate rental price from number of days
- SQLite database
- Simple web dashboard
- REST API through FastAPI
- Automatic API documentation

## Technology

- Python 3.10+
- FastAPI
- SQLite
- SQLAlchemy
- Uvicorn
- HTML/CSS/JavaScript

## Run locally

### 1. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Start the application

```bash
uvicorn app.main:app --reload
```

Open:

http://127.0.0.1:8000

API documentation:

http://127.0.0.1:8000/docs

## Project structure

```text
drone-rent/
├── app/
│   ├── __init__.py
│   ├── database.py
│   ├── main.py
│   ├── models.py
│   ├── schemas.py
│   ├── crud.py
│   ├── seed.py
│   └── static/
│       ├── index.html
│       ├── app.js
│       └── style.css
├── requirements.txt
├── .gitignore
└── README.md
```

## API endpoints

### Drones

- `GET /api/drones`
- `GET /api/drones/{id}`
- `POST /api/drones`
- `PUT /api/drones/{id}`
- `DELETE /api/drones/{id}`

### Rental

- `POST /api/drones/{id}/rent`
- `POST /api/drones/{id}/return`

### Health

- `GET /api/health`

## Example drone

```json
{
  "drone_id": "DR-001",
  "name": "DJI Agras T50",
  "category": "Agriculture",
  "manufacturer": "DJI",
  "model": "Agras T50",
  "serial_number": "DEMO-001",
  "purchase_date": "2026-01-15",
  "purchase_cost": 12000,
  "daily_rental_price": 500,
  "status": "AVAILABLE",
  "location": "Glasgow",
  "battery_count": 4,
  "flight_hours": 0,
  "last_maintenance": null,
  "next_maintenance": "2026-12-01",
  "notes": "Agricultural spraying drone"
}
```

## Seed demo data

```bash
python -m app.seed
```

This adds sample agriculture and event drones.

## Future versions

Possible next features:

- Customer management
- Booking calendar
- Payments/invoices
- Operator management
- Maintenance work orders
- Battery inventory
- Flight/job records
- Agriculture spraying jobs
- Event photography jobs
- User login and roles
- Cloud deployment
- PostgreSQL
- Mobile-friendly PWA
